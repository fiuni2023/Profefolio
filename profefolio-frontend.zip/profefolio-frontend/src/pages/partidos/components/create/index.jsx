import React from "react";
import {PanelContainerBG} from "../../../../components/Layout.jsx";
const CreatePartidos = ({children}) => {
    return (
        <>
            <PanelContainerBG>

            </PanelContainerBG>
        </>
    )
}

export default CreatePartidos