import React from "react";
import { PanelContainerBG } from "../../../../components/Layout.jsx";

const PartidosEdit = () => {
    return <>
        <PanelContainerBG>

        </PanelContainerBG>
    </>
}

export default PartidosEdit