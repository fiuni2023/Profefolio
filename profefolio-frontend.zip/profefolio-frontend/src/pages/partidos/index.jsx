import React from "react";
import { Outlet } from "react-router-dom";

const Partidos = () => {
    return (
        <>
            <Outlet />
        </>
    )
}

export default Partidos