import React from "react";

const Base = ({number}) =>{
    return(
        <>
            <span>asd {number}</span>
        </>
    )
}

export default Base